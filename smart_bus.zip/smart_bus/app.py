from flask import Flask, jsonify, request, send_from_directory
from flask_cors import CORS
import random

app = Flask(__name__, static_folder="static", static_url_path="")
CORS(app)  # keep for dev; same-origin is fine in prod

# ---------------- Mock / In-memory Data ----------------
stops = [
    {"id": 1, "name": "Central Station", "lat": 12.9716, "lng": 77.5946, "place": "Bengaluru"},
    {"id": 2, "name": "MG Road", "lat": 12.9764, "lng": 77.5990, "place": "Bengaluru"},
    {"id": 3, "name": "City Bus Depot", "lat": 12.9668, "lng": 77.5939, "place": "Bengaluru"},
    {"id": 4, "name": "Tech Park", "lat": 12.9346, "lng": 77.6197, "place": "Bengaluru"},
    {"id": 5, "name": "Airport", "lat": 13.1986, "lng": 77.7066, "place": "Bengaluru"},
]

buses = [
    {"id": "BUS-101", "route": [1, 2, 3, 4], "idx": 0, "lat": 12.9716, "lng": 77.5946, "speed": 0.0020},
    {"id": "BUS-32A", "route": [5, 4, 2, 1], "idx": 0, "lat": 13.1986, "lng": 77.7066, "speed": 0.0024},
]

users = {}          # username -> {logged_in: True}
saved_stops = {}    # username -> [stop_ids]

# ---------------- Helpers ----------------
def move_bus(bus):
    """Move a bus slightly toward its next stop each poll."""
    idx = bus.get("idx", 0)
    route_ids = bus["route"]
    if not route_ids:
        return bus

    # from/to stops
    from_id = route_ids[idx]
    to_id   = route_ids[(idx + 1) % len(route_ids)]
    from_stop = next((s for s in stops if s["id"] == from_id), None)
    to_stop   = next((s for s in stops if s["id"] == to_id), None)
    if not from_stop or not to_stop:
        return bus

    dx = to_stop["lat"] - from_stop["lat"]
    dy = to_stop["lng"] - from_stop["lng"]

    # move a fraction of the segment each call
    bus["lat"] += dx * bus["speed"]
    bus["lng"] += dy * bus["speed"]

    # if close enough, advance to next segment
    if abs(bus["lat"] - to_stop["lat"]) < 0.001 and abs(bus["lng"] - to_stop["lng"]) < 0.001:
        bus["idx"] = (idx + 1) % len(route_ids)

    return bus

# ---------------- Routes ----------------
@app.route("/")
def index():
    return send_from_directory(app.static_folder, "index.html")

@app.route("/stops", methods=["GET"])
def api_stops():
    return jsonify(stops)

@app.route("/buses", methods=["GET"])
def api_buses():
    global buses
    buses = [move_bus(dict(b)) for b in buses]  # simulate motion
    return jsonify(buses)

@app.route("/login", methods=["POST"])
def api_login():
    data = request.get_json(force=True)
    username = (data or {}).get("username")
    if not username:
        return jsonify({"error": "Missing username"}), 400
    users[username] = {"logged_in": True}
    saved_stops.setdefault(username, [])
    return jsonify({"message": f"Logged in as {username}"}), 200

@app.route("/saved", methods=["GET", "POST", "DELETE"])
def api_saved():
    username = request.args.get("user")
    if not username:
        return jsonify({"error": "Missing user"}), 400
    if username not in users:
        return jsonify({"error": "User not found / not logged in"}), 404

    if request.method == "GET":
        return jsonify(saved_stops.get(username, []))

    data = request.get_json(force=True) or {}
    stop_id = data.get("stop_id")
    if stop_id is None:
        return jsonify({"error": "Missing stop_id"}), 400

    if request.method == "POST":
        if stop_id not in saved_stops[username]:
            saved_stops[username].append(stop_id)
        return jsonify({"message": "Saved", "saved": saved_stops[username]})

    if request.method == "DELETE":
        saved_stops[username] = [sid for sid in saved_stops[username] if sid != stop_id]
        return jsonify({"message": "Removed", "saved": saved_stops[username]})

@app.route("/weather", methods=["GET"])
def api_weather():
    lat = request.args.get("lat", type=float)
    lon = request.args.get("lon", type=float)
    # demo weather
    status = random.choice(["Sunny", "Cloudy", "Partly Cloudy", "Rain"])
    return jsonify({
        "location": f"{lat:.2f},{lon:.2f}" if (lat and lon) else "Unknown",
        "status": status,
        "temp": f"{random.randint(25, 33)}°C",
        "desc": "Demo weather"
    })
if __name__ == "__main__":
    app.run(debug=True, port=8000)


