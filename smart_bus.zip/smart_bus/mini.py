from flask import Flask, send_from_directory

# Serve everything from /static and map "/" to static/index.html
app = Flask(__name__, static_folder="static", static_url_path="")

@app.route("/")
def home():
    # if index.html exists, this will serve it
    return send_from_directory(app.static_folder, "index.html")

@app.route("/ping")
def ping():
    return "pong"

if __name__ == "__main__":
    # If port 5000 is busy, change to 8000 and use that in your browser.
    app.run(debug=True, port=5000)
